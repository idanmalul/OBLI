<div id="content" data-id="<?php echo $verified_id;?>">
    <iframe class="iframe" style="height: 1000px; width: 100%;" scrolling="no" src="<?php echo $auth_url;?>" frameborder="0" allow="geolocation; microphone; camera"></iframe>
</div>